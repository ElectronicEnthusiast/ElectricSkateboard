BLE Heart Rate Demo

Connects to a peripherial providing the [Heart Rate Service](http://goo.gl/wKH3X7).

Works with iOS or Android 4.3+.

    $ cordova platform add android
    $ cordova plugin add cordova-plugin-ble-central
    $ cordova run
